# 0_Boas_Vindas
import streamlit as st
import os

st.set_page_config(page_title="Bem-vindo", layout="centered")

base_dir = os.getcwd()

caminho_vogais = os.path.join(base_dir, "assets", "letras", "vogais.png")

col1, col2, col3 = st.columns([1, 3, 1])

with col2:
    st.markdown("<h1 style='text-align: center;'>Bem-vindo(a)!</h1>", unsafe_allow_html=True)

    st.markdown("""
        <p style='text-align: center; font-size: 18px;'>
            Vamos começar aprendendo o alfabeto em LIBRAS.<br><br>
            Começaremos pelas vogais:
        </p>
    """, unsafe_allow_html=True)

    st.image(caminho_vogais, width=500)

    if st.button("Começar"):
        st.switch_page("pages/page2.py")
