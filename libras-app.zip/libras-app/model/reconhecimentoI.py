import cv2
import numpy as np
import mediapipe as mp
import joblib
import os
import time

base_dir = os.path.dirname(os.path.abspath(__file__))
caminho_modelo = os.path.join(base_dir)

modelo = joblib.load(os.path.join(caminho_modelo, "modelo_libras_knn.pkl"))
le = joblib.load(os.path.join(caminho_modelo, "label_encoder.pkl"))

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

print("Mostre a letra 'I' para a câmera e segure por 2 segundos.")

letra_alvo = "I"
tempo_necessario = 1 
tempo_inicial = None

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(img_rgb)

    predicao = None

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            dados = []
            for lm in hand_landmarks.landmark:
                dados.extend([lm.x, lm.y, lm.z])

            if len(dados) == 63:
                X_input = np.array(dados).reshape(1, -1)
                pred = modelo.predict(X_input)
                predicao = le.inverse_transform(pred)[0]

                if predicao == letra_alvo:
                    if tempo_inicial is None:
                        tempo_inicial = time.time()
                    else:
                        tempo_passado = time.time() - tempo_inicial
                        if tempo_passado >= tempo_necessario:
                            cv2.putText(frame, "Muito bem!", (50, 80),
                                        cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 3)
                            cv2.imshow("Reconhecimento LIBRAS", frame)
                            cv2.waitKey(2000)
                            cap.release()
                            cv2.destroyAllWindows()
                            hands.close()

                            def proxima_letra():
                                print("Agora vamos para a letra O!")

                            proxima_letra()
                            exit()
                else:
                    tempo_inicial = None 

            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
    else:
        tempo_inicial = None

    if predicao:
        cv2.putText(frame, f"Predito: {predicao}", (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

    cv2.imshow("Reconhecimento LIBRAS", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
hands.close()