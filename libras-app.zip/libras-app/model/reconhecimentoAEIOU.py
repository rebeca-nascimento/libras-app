import cv2
import numpy as np
import mediapipe as mp
import joblib
import os
import time

base_dir = os.path.dirname(os.path.abspath(__file__))
caminho_modelo = os.path.join(base_dir)

modelo = joblib.load(os.path.join(caminho_modelo, "modelo_libras_knn.pkl"))
le = joblib.load(os.path.join(caminho_modelo, "label_encoder.pkl"))

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)
mp_drawing = mp.solutions.drawing_utils

cap = cv2.VideoCapture(0)

sequencia_correta = ["A", "E", "I", "O", "U"]
entrada_usuario = []
ultimo_sinal = None
tempo_ultimo = time.time()
mensagem = "Faca o sinal da letra A"
cor_mensagem = (0, 255, 255)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    h, w, _ = frame.shape
    img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(img_rgb)

    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            dados = []
            for lm in hand_landmarks.landmark:
                dados.extend([lm.x, lm.y, lm.z])
            
            if len(dados) == 63:
                X_input = np.array(dados).reshape(1, -1)
                pred = modelo.predict(X_input)
                letra = le.inverse_transform(pred)[0]

                if letra != ultimo_sinal and time.time() - tempo_ultimo > 1.5:
                    entrada_usuario.append(letra)
                    tempo_ultimo = time.time()
                    ultimo_sinal = letra

                    if entrada_usuario != sequencia_correta[:len(entrada_usuario)]:
                        mensagem = "Sequencia incorreta! Recomece"
                        cor_mensagem = (0, 0, 255)
                        entrada_usuario = []
                        time.sleep(1.5)
                    elif entrada_usuario == sequencia_correta:
                        mensagem = "Muito bem! Sequencia completa!"
                        cor_mensagem = (0, 255, 0)
                        cv2.putText(frame, mensagem, (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.1, cor_mensagem, 3)
                        cv2.imshow('Reconhecimento LIBRAS - AEIOU', frame)
                        cv2.waitKey(3000)
                        cap.release()
                        cv2.destroyAllWindows()
                        hands.close()
                        exit()
                    else:
                        proxima = sequencia_correta[len(entrada_usuario)]
                        mensagem = f"Letra {letra} correta. Agora, faca {proxima}."
                        cor_mensagem = (0, 255, 0)

            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

    texto_seq = "Sequencia: " + "-".join(entrada_usuario)
    cv2.putText(frame, texto_seq, (30, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

    cv2.putText(frame, mensagem, (30, 80), cv2.FONT_HERSHEY_SIMPLEX, 1.1, cor_mensagem, 3)

    cv2.imshow('Reconhecimento LIBRAS - AEIOU', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
hands.close()