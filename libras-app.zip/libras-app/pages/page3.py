import streamlit as st
import subprocess
import time
import os

base_dir = os.getcwd()

caminho_a = os.path.join(base_dir, "assets", "letras", "e.png")
caminho_modelo = os.path.join(base_dir, "model", "teste.ipynb")

st.set_page_config(page_title="Vogais - LIBRAS", layout="centered")

st.markdown("<h2 style='text-align: center;'>Aprendendo as Vogais em LIBRAS</h2>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Observe cada sinal e tente reproduzir com as mãos</p>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Vamos aprender a letra E agora:</p>", unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)

col1, col2, col3 = st.columns([1, 3, 1])
with col2:

    st.image(caminho_a, width=400)

    if st.button("Praticar com Câmera"):
        subprocess.Popen(["python", os.path.join(base_dir, "model", "reconhecimentoE.py")])
        st.warning("Aplicativo de câmera aberto em uma janela externa.")
        time.sleep(30)

        st.switch_page("pages/page4.py")
