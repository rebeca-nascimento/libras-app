import streamlit as st
import os

st.set_page_config(page_title="Vogais - LIBRAS", layout="centered")

st.markdown("<h2 style='text-align: center;'>Aprendendo as Vogais em LIBRAS</h2>", unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)

st.markdown("<p style='text-align: center;'>Muito bem você finalizou a sessão das vogais!</h2>", unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)
