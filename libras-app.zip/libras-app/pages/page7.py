import streamlit as st
import subprocess
import time
import os

base_dir = os.getcwd()

st.set_page_config(page_title="Vogais - LIBRAS", layout="centered")

st.markdown("<h2 style='text-align: center;'>Aprendendo as Vogais em LIBRAS</h2>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Agora que você já aprendeu todas as vogais em LIBRAS, faça a sequência A-E-I-O-U:</p>", unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)

col1, col2, col3 = st.columns([1, 3, 1])
with col2:

    if st.button("Praticar com Câmera"):
        subprocess.Popen(["python", os.path.join(base_dir, "model", "reconhecimentoAEIOU.py")])
        st.warning("Aplicativo de câmera aberto em uma janela externa.")
        time.sleep(20)

        st.switch_page("pages/page8.py")